// import './App.css';
import { BrowserRouter, Route, Routes, useSearchParams } from 'react-router-dom';

// React Notification
import 'react-notifications/lib/notifications.css';
import { NotificationContainer } from 'react-notifications';


import LoginForm from './views/auth/login';
import RegisterUser from './views/users/register';
import HomePage from './views/home/home';
import NoPage from './views/nopage';
import UserPage from './views/users/userpage';
import MainHeader from './components/mainheader';
import MainFooter from './components/mainfooter';
import ProductOverview from './views/products/product_overview';
import { useState } from 'react';
import ProductManager from './views/products/product_manager';
import LandingPage from './views/home/landing';


function App() {

  return (
    <div>
      <header >
      <BrowserRouter>
      <MainHeader/>
        <Routes>
          <Route exact path='/' element={<LandingPage/>} />
          <Route exact path='/home' element={<HomePage/>} />
          <Route path='/user-registration' element={<RegisterUser/>} />
          <Route path='/login' element={<LoginForm/>} />
          <Route path='/users' element={<UserPage/>} />
          <Route path='/product-detail' element={<ProductOverview/>} />
          <Route path='/product' element={<ProductManager/>} />
          <Route path='*' element={<NoPage/>}/>

         
        </Routes>
        <MainFooter />
      <NotificationContainer/>
    </BrowserRouter>
      </header>
    </div>
  );
}

export default App;
