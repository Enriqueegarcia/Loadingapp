import apiService from '../../services/api_service';

//Service to handle all the call to the API for products


// GET request to retrieve data
export const  getProducts = async () => {
    try {
        const data  = await apiService.get('/product');
        return data.data;
    } catch (error) {
        console.log(error);
    }
  };

  export const  getMostWantedProducts = async () => {
    try {
        const data  = await apiService.get('/product/mostwanted');
        return data.data;
    } catch (error) {
        console.log(error);
    }
  };

    // Get request to Get Product by Id
    export const getProductsById = async (postId) => {
      const data = await apiService.get(`/product/${postId}`);
        return data.data;
      };
  
  // POST request to create data
  export const createProducts = async (postData) => {
    return apiService.post('/product', postData);
  };
  
  // PUT request to update data
  export const updateProducts = async (updatedData) => {
    return apiService.put(`/product`, updatedData);
  };
  
  // DELETE request to delete data
  export const deleteProducts = async (postId) => {
    return apiService.delete(`/product/${postId}`);
  };