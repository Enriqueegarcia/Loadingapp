import { useLocation } from 'react-router-dom';

export default function ProductOverview() {
    const { state } = useLocation();

    return (
        <div className="bg-white">
            <div className="pb-16 pt-6 sm:pb-24">
                <div className="mx-auto mt-8 max-w-2xl px-4 sm:px-6 lg:max-w-7xl lg:px-8">
                    <div className="lg:grid lg:auto-rows-min lg:grid-cols-12 lg:gap-x-8">
                        <div className="lg:col-span-5 lg:col-start-8">
                            <div className="flex justify-between">
                                <h1 className="text-xl font-medium text-gray-900">{state.product_name}</h1>
                                <p className="text-xl font-medium text-gray-900">${state.product_cost}</p>
                            </div>
                        </div>
                        {/* Image gallery */}
                        <div className="mt-8 lg:col-span-7 lg:col-start-1 lg:row-span-3 lg:row-start-1 lg:mt-0">
                            <h2 className="sr-only">Images</h2>

                            <div className="grid grid-cols-1 lg:grid-cols-2 lg:grid-rows-3 lg:gap-8">
                            <img                             
                                        src={state.product_image}
                                        alt={state.product_image_alt}
                                        className='lg:col-span-2 lg:row-span-2'
                                    />
                            </div>
                        </div>
                        <div className="mt-8 lg:col-span-5">
                            <form>
                                {/* Color picker */}
                                <div>
                                    <h2 className="text-sm font-medium text-gray-900">Color</h2>
                                    <h3 className="text-sm font-medium text-gray-900">{state.product_color}</h3>
                                </div>

                                {/* Size picker */}
                                {/* <div className="mt-8">
                                    <div className="flex items-center justify-between">
                                        <h2 className="text-sm font-medium text-gray-900">Size</h2>
                                        <h3 className="text-sm font-medium text-gray-900">{state.product_color}</h3>
                                    </div>

                                    <RadioGroup value={selectedSize} onChange={setSelectedSize} className="mt-2">
                                        <RadioGroup.Label className="sr-only">Choose a size</RadioGroup.Label>
                                        <div className="grid grid-cols-3 gap-3 sm:grid-cols-6">
                                            {product.sizes.map((size) => (
                                                <RadioGroup.Option
                                                    key={size.name}
                                                    value={size}
                                                    className={({ active, checked }) =>
                                                        classNames(
                                                            size.inStock ? 'cursor-pointer focus:outline-none' : 'cursor-not-allowed opacity-25',
                                                            active ? 'ring-2 ring-indigo-500 ring-offset-2' : '',
                                                            checked
                                                                ? 'border-transparent bg-indigo-600 text-white hover:bg-indigo-700'
                                                                : 'border-gray-200 bg-white text-gray-900 hover:bg-gray-50',
                                                            'flex items-center justify-center rounded-md border py-3 px-3 text-sm font-medium uppercase sm:flex-1'
                                                        )
                                                    }
                                                    disabled={!size.inStock}
                                                >
                                                    <RadioGroup.Label as="span">{size.name}</RadioGroup.Label>
                                                </RadioGroup.Option>
                                            ))}
                                        </div>
                                    </RadioGroup>
                                </div> */}

                                <button
                                    type="submit"
                                    className="mt-8 flex w-full items-center justify-center rounded-md border border-transparent bg-indigo-600 px-8 py-3 text-base font-medium text-white hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                                >
                                    Add to cart
                                </button>
                            </form>

                            {/* Product details */}
                            <div className="mt-10">
                                <h2 className="text-sm font-medium text-gray-900">Description</h2>

                                <div
                                    className="prose prose-sm mt-4 text-gray-500"
                                    dangerouslySetInnerHTML={{ __html: state.product_description }}
                                />
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
