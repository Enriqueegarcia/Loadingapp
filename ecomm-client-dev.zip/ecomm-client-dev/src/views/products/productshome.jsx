import { Fragment, useState, useEffect, useCallback } from 'react'
import { Dialog, Disclosure, Popover, Tab, Transition } from '@headlessui/react'
import { Bars3Icon, MagnifyingGlassIcon, ShoppingBagIcon, XMarkIcon } from '@heroicons/react/24/outline'
import { ChevronDownIcon, PlusIcon } from '@heroicons/react/20/solid'
import { Link } from 'react-router-dom';
import { getProducts } from './product_service';
import ProductsHomeItems from '../../components/products_home_item';
import MostWanted from '../../components/mostwantedproducts';
import SearchBar from '../../components/searchbar';



const ProductsHomeBody = () => {

    const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
    const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false)
    const [products, setProducts] = useState([]);
    const [activeFilter, setActiveFilter] = useState([]);
    const [filteredList, setFilteredList] = useState([]);
    
    useEffect(() => {
        // Fetch products when the component mounts
        getProducts()
            .then((response) => {
                setProducts(response.data);
                setFilteredList(response.data);
                console.log(response.data);
            })
            .catch((error) => {
                console.error('Error fetching products:', error);
            });
    }, []);
    const filters = [
        {
            id: 'color',
            name: 'Color',
            options: [
                { value: 'White', label: 'White' },
                { value: 'Black', label: 'Black' },
                { value: 'Blue', label: 'Blue' },
                { value: 'Brown', label: 'Brown' },
                { value: 'Green', label: 'Green' },
                { value: 'Purple', label: 'Purple' },
            ],
        },
        {
            id: 'category',
            name: 'Category',
            options: [
                { value: 1, label: 'All New Arrivals' },
                { value: 2, label: 'Tees' },
                { value: 3, label: 'Crewnecks' },
                { value: 4, label: 'Sweatshirts' },
                { value: 5, label: 'Pants & Shorts' },
            ],
        },
        // {
        //     id: 'sizes',
        //     name: 'Sizes',
        //     options: [
        //         { value: 'xs', label: 'XS' },
        //         { value: 's', label: 'S' },
        //         { value: 'm', label: 'M' },
        //         { value: 'l', label: 'L' },
        //         { value: 'xl', label: 'XL' },
        //         { value: '2xl', label: '2XL' },
        //     ],
        // },
    ]


  

 const onFilterChange = (event) =>{
    let newActive = {}

    console.log('Antes: ',activeFilter);

    if (event.target.checked) {
        setActiveFilter([...activeFilter, event.target.value])
        newActive = [...activeFilter, event.target.value]
      } else {
        setActiveFilter(
            activeFilter.filter((item) => item !== event.target.value)
        )
        newActive =  activeFilter.filter((item) => item !== event.target.value)
      }

      
      const filter = products.filter((product) =>  
      newActive.length > 0
        ? newActive.includes(product.product_color || product.category_id.toString())
        : products
     )
     console.log('Despues New Active:', newActive);
     setFilteredList(filter);
 };


 const handleSearchBar = useCallback((text) => {
    const searchFilteredList = text.length > 0 ? products.filter((p) => p.product_name.includes(text),) :products
    setFilteredList(searchFilteredList);

 },[filteredList]);
    return (
        
        <div className="mx-auto max-w-2xl px-4 lg:max-w-7xl lg:px-8">
            <div className="border-b border-gray-200 pb-10 pt-24">
                <h1 className="text-4xl font-bold tracking-tight text-gray-900">New Arrivals</h1>
                <p className="mt-4 text-base text-gray-500">
                    Checkout out the latest release of Basic Tees!
                </p>
            </div>
            <div className="pb-24 pt-12 lg:grid lg:grid-cols-3 lg:gap-x-8 xl:grid-cols-4">
                <aside>
                    <h2 className="sr-only">Filters</h2>

                    <button
                        type="button"
                        className="inline-flex items-center lg:hidden"
                        onClick={() => setMobileFiltersOpen(true)}
                    >
                        <span className="text-sm font-medium text-gray-700">Filters</span>
                        <PlusIcon className="ml-1 h-5 w-5 flex-shrink-0 text-gray-400" aria-hidden="true" />
                    </button>

                    <div className="hidden lg:block">
                        <form className="space-y-10 divide-y divide-gray-200">
                            {/* Search Bar Component */}
                            <SearchBar onChange={handleSearchBar}/>

                            {filters.map((section, sectionIdx) => (
                                <div key={section.name} className={sectionIdx === 0 ? null : 'pt-10'}>
                                    <fieldset>
                                        <legend className="block text-sm font-medium text-gray-900">{section.name}</legend>
                                        <div className="space-y-3 pt-6">
                                            {section.options.map((option, optionIdx) => (
                                              
                                                <div key={option.value} className="flex items-center">
                                                    <input
                                                        id={`${section.id}-${optionIdx}`}
                                                        name={`${section.id}[]`}
                                                        value={option.value}
                                                        onChange={onFilterChange}
                                                        //checked={activeFilter.includes(option.value)}
                                                        type="checkbox"
                                                        className="h-4 w-4 rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
                                                    />
                                                    <label htmlFor={`${section.id}-${optionIdx}`} className="ml-3 text-sm text-gray-600">
                                                        {option.label}
                                                    </label>
                                                </div> 
                                            ))}
                                        </div>
                                    </fieldset>
                                </div>
                            ))}
                        </form>
                    </div>
                </aside>

                <section aria-labelledby="product-heading" className="mt-6 lg:col-span-2 lg:mt-0 xl:col-span-3">
                    <h2 id="product-heading" className="sr-only">
                        Products
                    </h2>

                    <ProductsHomeItems products={filteredList} />

                </section>
                <section aria-labelledby="product-heading" className="mt-6 lg:col-span-2 lg:mt-0 xl:col-span-3">
                    <h2 id="product-heading" className="sr-only">
                        Most Wanted
                    </h2>

                    <MostWanted />

                </section>
            </div>
        </div>
    )
}

export default ProductsHomeBody