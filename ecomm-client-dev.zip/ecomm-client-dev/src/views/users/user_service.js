import apiService from '../../services/api_service';

//Service to handle all the call to the API for user


// GET request to retrieve data
export const  getAllUser = async () => {
    try {
        const data  = await apiService.get('/user');
        return data.data;
    } catch (error) {
        console.log(error);
    }
  };

    // DELETE request to delete data
    export const getUserByUsername = (postId) => {
        return apiService.get(`/user/${postId}`);
      };
  
  // POST request to create data
  export const createUser = (postData) => {
    return apiService.post('/user', postData);
  };
  
  // PUT request to update data
  export const updateUser = (updatedData) => {
    return apiService.put(`/user`, updatedData);
  };
  
  // DELETE request to delete data
  export const deleteUser = (id) => {
    return apiService.delete(`/user/${id}`);
  };