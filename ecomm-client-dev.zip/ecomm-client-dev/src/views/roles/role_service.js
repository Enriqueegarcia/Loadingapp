import apiService from '../../services/api_service';

//Service to handle all the call to the API


// GET request to retrieve data
export const  getRoles = async () => {
    try {
        const data  = await apiService.get('/role');
        return data.data;
    } catch (error) {
        console.log(error);
    }
  };

    // Get request to Get Role by Id
    export const getRoleById = async (postId) => {
      const data = await apiService.get(`/role/${postId}`);
        return data.data;
      };
  
  // POST request to create data
  export const createRole = async (postData) => {
    return apiService.post('/role', postData);
  };
  
  // PUT request to update data
  export const updateRole = async (updatedData) => {
    return apiService.put(`/role`, updatedData);
  };
  
  // DELETE request to delete data
  export const deleteRole = async (postId) => {
    return apiService.delete(`/role/${postId}`);
  };