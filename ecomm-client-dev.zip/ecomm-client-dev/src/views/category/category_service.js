import apiService from '../../services/api_service';

//Service to handle all the call to the API


// GET request to retrieve data
export const  getCategory = async () => {
    try {
        const data  = await apiService.get('/category');
        return data.data;
    } catch (error) {
        console.log(error);
    }
  };

    // Get request to Get Product by Id
    export const getCategoryById = async (postId) => {
      const data = await apiService.get(`/category/${postId}`);
        return data.data;
      };
  
  // POST request to create data
  export const createCategory = async (postData) => {
    return apiService.post('/category', postData);
  };
  
  // PUT request to update data
  export const updateCategory = async (postId, updatedData) => {
    return apiService.put(`/category/${postId}`, updatedData);
  };
  
  // DELETE request to delete data
  export const deleteCategory = async (postId) => {
    return apiService.delete(`/category/${postId}`);
  };