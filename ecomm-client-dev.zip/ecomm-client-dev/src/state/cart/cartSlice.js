import { createSlice } from "@reduxjs/toolkit"

const initialState = {
  cartItems: [],
  cartQty: Number
}

const cartSlice = createSlice({
  name: "cart",
  initialState,
  reducers: {
    addItemToCartState: (state, action) => {
      state.cartItems = action.payload
      state.cartQty += 1
    },
    deleteItemToCartState: state => {
      state.cartItems = null
      state.cartQty -= 1
    }
  }
})


export const { addItemToCartState, deleteItemToCartState} = cartSlice.actions

export default cartSlice.reducer
