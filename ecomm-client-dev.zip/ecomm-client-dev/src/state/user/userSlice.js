import { createSlice } from "@reduxjs/toolkit"

const initialState = {
  value: {},
  isLogin: Boolean
}

const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    saveUserState: (state, action) => {
      state.value = action.payload
    },
    deleteUserState: state => {
      state.value = null
    },
    isUserLogin: state => {
      state.isLogin = state.value? true: false
    }
  }
})


export const { saveUserState, deleteUserState, isUserLogin} = userSlice.actions

export default userSlice.reducer
