import React from 'react'

const MainBody = ({renderpage}) => {
  const NewComponent = renderpage;
      return (
        <main className="mx-auto max-w-2xl px-4 lg:max-w-7xl lg:px-8">
       <NewComponent/>
     </main>
      )
    };

export default MainBody;