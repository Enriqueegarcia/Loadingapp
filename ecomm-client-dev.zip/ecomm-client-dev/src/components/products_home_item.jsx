import { Link } from 'react-router-dom';
import { PlusIcon } from '@heroicons/react/20/solid'

const ProductsHomeItems = ({ products }) => {

  return (
    products.length > 0? 
    <div className="grid grid-cols-1 gap-y-4 sm:grid-cols-2 sm:gap-x-6 sm:gap-y-10 lg:gap-x-8 xl:grid-cols-3">
      {products.map((product) => (
        <div
          key={product.id}
          className="group relative flex flex-col overflow-hidden rounded-lg border border-gray-200 bg-white"
        >
          <div className="aspect-h-4 aspect-w-3 bg-gray-200 sm:aspect-none group-hover:opacity-75 sm:h-96">
            <img
              src={product.product_image}
              alt={product.product_image_alt}
              className="h-full w-full object-cover object-center sm:h-full sm:w-full"
            />
          </div>
          <div className="flex flex-1 flex-col space-y-2 p-4">
            <h3 className="text-sm font-medium text-gray-900">
              <Link to='/product-detail' state={product}>
              <span aria-hidden="true" className="absolute inset-0" />
                {product.product_name + ' - ' + product.gender_type}
              </Link>
            </h3>
            <p className="text-sm text-gray-500">{product.product_description}</p>
            <div className="flex flex-1 flex-col justify-end">
              <p className="text-sm italic text-gray-500">{product.product_color}</p>
              <p className="text-base font-medium text-gray-900">${product.product_cost}</p>
            </div>
          </div>
        </div>
      ))}
    </div>
    :
    <div className="text-center">
      <svg
        className="mx-auto h-12 w-12 text-gray-400"
        fill="none"
        viewBox="0 0 24 24"
        stroke="currentColor"
        aria-hidden="true"
      >
        <path
          vectorEffect="non-scaling-stroke"
          strokeLinecap="round"
          strokeLinejoin="round"
          strokeWidth={2}
          d="M9 13h6m-3-3v6m-9 1V7a2 2 0 012-2h6l2 2h6a2 2 0 012 2v8a2 2 0 01-2 2H5a2 2 0 01-2-2z"
        />
      </svg>
      <h3 className="mt-2 text-sm font-semibold text-gray-900">Empty</h3>
      <p className="mt-1 text-sm text-gray-500">No products found that matched your selection.</p>
    </div>
  )
};

export default ProductsHomeItems;