import { useState, memo} from 'react';

function SearchBar({ onChange }) {
 

  return (
  
    <input 
      type="text" 
      onChange={e => onChange(e.target.value)}
      placeholder="Search..."
      className="rounded border-gray-300 text-indigo-600 focus:ring-indigo-500"
    />
  
 
  );
}

export default memo(SearchBar);