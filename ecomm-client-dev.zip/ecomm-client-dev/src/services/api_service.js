import axios from 'axios';

// Create an Axios instance with a base URL
const apiService = axios.create({
    baseURL: 'http://localhost:8001/api', // Replace with your API endpoint
    // You can also set headers or other configuration options here
  });

  export default apiService;